NAME = 'hello.scripts.say_hello'
